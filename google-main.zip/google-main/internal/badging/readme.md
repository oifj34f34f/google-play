# Badging

https://developer.android.com/guide/topics/manifest/uses-feature-element
